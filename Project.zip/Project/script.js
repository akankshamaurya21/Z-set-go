const places = [
    'Paris', 
    'New York', 
    'Tokyo', 
    'Rome', 
    'London', 
    'Dubai', 
    'Sydney', 
    'Barcelona', 
    'Bangkok', 
    'Amsterdam', 
    'Cape Town', 
    'Rio de Janeiro', 
    'Los Angeles', 
    'San Francisco', 
    'Berlin', 
    'Seoul', 
    'Singapore', 
    'Kuala Lumpur', 
    'Madrid'
  ];
  
  // Function to display the places
  function displayPlaces(filteredPlaces) {
    const placesList = document.getElementById('placesList');
    placesList.innerHTML = ''; // Clear current list
  
    if (filteredPlaces.length > 0) {
      placesList.style.display = 'block'; // Show suggestions
      filteredPlaces.forEach(place => {
        const li = document.createElement('li');
        li.textContent = place;
        li.onclick = () => selectPlace(place); // Handle selection
        placesList.appendChild(li);
      });
    } else {
      placesList.style.display = 'none'; // Hide suggestions when no matches
    }
  }
  
  // Search function that filters places
  function searchPlaces() {
    const searchTerm = document.getElementById('searchBar').value.toLowerCase();
    const filteredPlaces = places.filter(place => 
      place.toLowerCase().includes(searchTerm)
    );
    displayPlaces(filteredPlaces);
  }
  
  // Handle selection of a suggestion
  function selectPlace(place) {
    document.getElementById('searchBar').value = place; // Set the search bar value
    document.getElementById('placesList').style.display = 'none'; // Hide suggestions
  }
  
  // Optional: Close suggestions if the user clicks outside
  document.addEventListener('click', function(event) {
    if (!event.target.closest('#searchBar') && !event.target.closest('#placesList')) {
      document.getElementById('placesList').style.display = 'none';
    }
  });



  // script.js


